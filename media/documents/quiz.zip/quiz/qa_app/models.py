from django.db import models

class Question(models.Model):

    Title = models.CharField(max_length=50, null=True)
    private = models.CharField(max_length=255, null=True)
    user_id = models.IntegerField(default=1)

    class Meta:
        db_table = 'tbl_question'
        select_on_save = True

class Answer(models.Model):

    body = models.CharField(max_length=255, null=True)
    question_id = models.CharField(max_length=255, null=True)
    user_id = models.IntegerField(default=1)

    class Meta:
        db_table = 'tbl_answer'
        select_on_save = True

class Tenant(models.Model):

    name = models.CharField(max_length=255, null=True)
    api_key = models.CharField(max_length=255, null=True)

    class Meta:
        db_table = 'tbl_tenant'
        select_on_save = True

class User(models.Model):

    name = models.CharField(max_length=255, null=True)

    class Meta:
        db_table = 'tbl_user'
        select_on_save = True


