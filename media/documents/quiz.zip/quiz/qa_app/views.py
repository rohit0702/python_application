from django.http import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status as http_status
from braces.views import CsrfExemptMixin
from qa_app_serializer import QASerializer,QADetailsSerializer,QuestionAnswerSerializer
from .models import Question,Answer,Tenant,User





class QuizInternalAPIView(CsrfExemptMixin, APIView):
    """
    Quiz internal API
    """
    def post(self, request):
        try:
            serializer = QASerializer(data=request.data)
            if serializer.is_valid():
                if request.data["callName"] == "QADetails":
                    qa_detail_serializer = QADetailsSerializer(data=request.data)
                    if qa_detail_serializer.is_valid():
                        qa_data = qa_detail_serializer.data['inputData']
                        is_create = self.update_qa_master_api(qa_data)
                        if is_create:
                            return Response("Successfully insert QA details")
                        else:
                            return Response("Something went wrong")
                    else:
                        return Response(qa_detail_serializer.errors)
                elif request.data["callName"] == "que_ans":
                    que_ans_serializer = QuestionAnswerSerializer(data=request.data)
                    if que_ans_serializer.is_valid():
                        que_ans_data = que_ans_serializer.data['inputData']
                        is_create = self.get_answer(que_ans_data)
                        if is_create:
                            return Response(is_create)
                        elif is_create == 'invalid api key':
                            return Response("Api Key is not present in the system")
                        else:
                            return Response("Something went wrong")
                    else:
                        return Response(que_ans_serializer.errors)
                else:
                    pass
            else:
                return Response(serializer.errors)
        except Exception as e:
            return Response({'message': 'Invalid passed data', 'success': 'False'},http_status.HTTP_400_BAD_REQUEST)

    def update_qa_master_api(self,qa_data):
        try:
            if qa_data:
                title = qa_data.get('title','NA')
                private = qa_data.get('private','NA')
                user_id= qa_data.get('user_id',0)
                que = Question.objects.create(Title=title,private=private,user_id=user_id)
                if que:
                    return True
        except Exception as e:
            return False
        return True

    def get_answer(self,que_ans_data):
        try:
            if que_ans_data:
                answer_dict = {}
                question = que_ans_data.get('question')
                api_key = que_ans_data.get('api_key')
                user_id = que_ans_data.get('user_id')
                is_question = Question.objects.filter(Title = question)
                if is_question:
                    question_obj = is_question.last()
                    is_answer = Answer.objects.filter(question_id = question_obj.id)
                    if is_answer:
                        answer_obj = is_answer.last()
                        answer = answer_obj.body
                tenant_obj = Tenant.objects.filter(api_key=api_key).last()
                if tenant_obj:
                    is_user = User.objects.filter(id=user_id).last()
                    if is_user:
                        user_name = is_user.name
                    else:
                        user_name = ''
                    answer_dict.update({"question":question,"api_key":api_key,
                                        "answer":answer,"user_name":user_name})
                    return answer_dict
                else:
                    return "invalid api key"
        except Exception as e:
            return False
        return True