from django.conf.urls import url
from views import QuizInternalAPIView

from . import views

urlpatterns = [
    #url(r'^$', views.index, name='index'),
    url("$", QuizInternalAPIView.as_view(), name='internal-process'),
]