# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Answer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('body', models.CharField(max_length=255, null=True)),
                ('question_id', models.CharField(max_length=255, null=True)),
                ('user_id', models.IntegerField(default=1)),
            ],
            options={
                'db_table': 'tbl_answer',
                'select_on_save': True,
            },
        ),
        migrations.CreateModel(
            name='Question',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Title', models.CharField(max_length=50, null=True)),
                ('private', models.CharField(max_length=255, null=True)),
                ('user_id', models.IntegerField(default=1)),
            ],
            options={
                'db_table': 'tbl_question',
                'select_on_save': True,
            },
        ),
        migrations.CreateModel(
            name='Tenant',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255, null=True)),
                ('api_key', models.CharField(max_length=255, null=True)),
                ('user_id', models.IntegerField(default=1)),
            ],
            options={
                'db_table': 'tbl_tenant',
                'select_on_save': True,
            },
        ),
        migrations.CreateModel(
            name='User',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255, null=True)),
            ],
            options={
                'db_table': 'tbl_user',
                'select_on_save': True,
            },
        ),
    ]
