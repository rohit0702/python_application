from rest_framework import serializers



class QASerializer(serializers.Serializer):
    """
    Serializer for QA APP
    """
    callName = serializers.CharField(max_length=50)
    inputData = serializers.JSONField()



class QADetailsSerializer(QASerializer):
    """
    QA details serializer
    """
    def validate_inputData(self, value):
        """
        :param value:
        :return:
        """
        qa_details_key = ["title","private","user_id"]
        data_keys = value.keys()
        if not all(map(lambda x: x in data_keys, qa_details_key)):
            raise serializers.ValidationError("Wrong data")
        return value

class QuestionAnswerSerializer(QASerializer):
    """
    QA details serializer
    """
    def validate_inputData(self, value):
        """
        :param value:
        :return:
        """
        qa_details_key = ["question","api_key","user_id"]
        data_keys = value.keys()
        if not all(map(lambda x: x in data_keys, qa_details_key)):
            raise serializers.ValidationError("Wrong data")
        return value

